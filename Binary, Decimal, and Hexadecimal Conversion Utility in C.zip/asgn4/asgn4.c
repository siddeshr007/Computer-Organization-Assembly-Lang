#include <stdio.h>
#include <stdbool.h>
#include "asgn4.h"

int main(){
int *binary = convertDecToBin(65535);
printMyBinaryNum(binary);
int decimal = convertBinToDec(binary);
printf ("\n %d \n", decimal);
int *hex = convertDectoHex(65535);
printMyHexNum(hex);
decimal = convertHexToDec(hex);
printf ("%d", decimal);
}