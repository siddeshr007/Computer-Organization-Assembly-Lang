#ifndef __asgn4__
#define __asgn4__
/* the two lines above check to ensure
we haven't already included this header*/

/* any needed include statements can go here */
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#define NUMBER_OF_BITS 16        
#define NUMBER_OF_HEX_DIGITS 4

int* convertDecToBin(int num){
int* binary = (int*) malloc(NUMBER_OF_BITS * sizeof (int));
int i = 0;
while (num > 0) {
    *(binary + (NUMBER_OF_BITS - 1 - i)) = num % 2;
    num /= 2;
    i++;
}
return binary;
}

int convertBinToDec(int* binary){
    int decimal = 0;
    for (int i = NUMBER_OF_BITS - 1; i >= 0; i--) {
        decimal += *(binary + i) * (pow(2, (NUMBER_OF_BITS - 1 - i)));
    }
    return decimal;
}

int* convertDectoHex(int decimal){
int* hex = (int*) malloc(NUMBER_OF_HEX_DIGITS * sizeof (int));
int i = 0;
while (decimal > 0) {
    *(hex + (NUMBER_OF_HEX_DIGITS - 1 - i)) = decimal % 16;
    decimal /= 16;
    i++;
}
return hex;
}
int convertHexToDec(int *hexarray){
   int decimal = 0;
    for (int i = NUMBER_OF_HEX_DIGITS - 1; i >= 0; i--) {
        decimal += *(hexarray + i) * (pow(16, (NUMBER_OF_HEX_DIGITS - 1 - i)));
    } 
    return decimal;
}
void printMyBinaryNum(int *myNumArray){
  for(int i = 0; i < NUMBER_OF_BITS; i++){
    if(i % 4 == 0 && i != 0) {
      printf(" %d", *(myNumArray + i));
    }
    else{
      printf("%d", *(myNumArray + i));
      
    }
  }
}
void printMyHexNum(int *myNumArray){
    printf("0x");
    for(int i = 0; i < NUMBER_OF_HEX_DIGITS; i++){
        printf("%d ", * (myNumArray + i));
    }
    printf("\n");  
    }

    #endif