#ifndef __asgn2__
#define __asgn2__

/* the two lines above check to ensure
we haven't already included this header*/


/* your functions go here */
// Note: main() goes in the asgn2.c file
#include <stdbool.h>
#include <stdio.h>
#include <math.h>

void grader(float avg_exams, float avg_hw, int attendance) {
    if (attendance <= 20) {
        printf("FAIL");
    } else if (avg_exams <= 70 || avg_hw <= 70) {
        printf("FAIL");
    } else if (avg_exams <= 85 && avg_hw <= 85) {
        printf("FAIL");
    } else {
        printf("PASS");
    }
}


void cubeOfOdd(int n2) {
for (int i = 0; i < n2; i++) {
if (i % 2 == 1) {
int result = pow(i, 3);
printf("%d ", result);
}
}
printf("\n");
}

void introToCS330(int n2) {
    int i;
    int flag = 0;
    for (i = 2; i <= n2 / 2; i++) {
        if (n2 % i == 0) {
            flag = 1;
            break;
        }
    }
    if (n2 % 3 == 0 && n2 % 7 == 0) {
        printf("CS");
    } else if (n2 % 7 == 0) {
        printf("UAB");
    } else if (n2 % 3 == 0) {
        printf("64");
    } else if (flag == 0) {
        printf("Go Blazers");
    } else if (n2 % 3 == 0 && n2 % 7 == 0){
      printf("UAB CS 330");
    } else {
        printf("%d \n", n2*n2*n2);
    }
}

int paintGallons(float length, float width, float height) {
float area = 2 * (length * height) + 2 * (length * width) + 2 * (width * height);
int paint = ceil(area / 400);
return paint;
}

void printHELLO(int n) {
for(int i = 0, c = 1; i <= n; i++) {
if(i == c) {
printf("HELLO");
c <<= 1;
}
else
printf("%d \n", i);
}
}

#endif