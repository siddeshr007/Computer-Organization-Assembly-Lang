#include <stdbool.h>
#include "asgn2.h"

int main (){
int avg_exams = 78;
int avg_hw = 88;
int attendance = 22;
grader(avg_exams, avg_hw, attendance);

int n2 = 8;
cubeOfOdd(n2);


introToCS330(42);


printf("%d \n " , paintGallons(10, 12, 8));


printHELLO(7);
return 0;
}

