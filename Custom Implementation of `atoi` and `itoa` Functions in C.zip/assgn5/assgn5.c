#include <stdio.h>
#include<stdlib.h>
#include "assgn5.h"

int main(){
    int n = atoi_cs330 ("-567"); 
    printf ("%d\n", n);
    char* num = itoa_cs330 (765);
    printf ("%s", num);
}
