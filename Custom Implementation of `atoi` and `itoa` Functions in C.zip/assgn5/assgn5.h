#ifndef __asgn5__
#define __asgn5__

/* the two lines above check to ensure
we haven't already included this header*/



#include <stdio.h>
#include<stdlib.h>

int atoi_cs330(const char* str) {
    int result = 0;
    int sign = 1;
if (*(str+0) == '\0'){
    return 0;
}
    for (int i = 0; *(str + i) != '\0'; i++){
        if (*(str+i) == '-'){
            sign = -1;
            continue;
        }
        int digit = *(str + i) - '0';
        result = (result * 10) + digit;
    }
  return result * sign;
}

char* itoa_cs330(int num) {
    int count = 0; 
    int sign = 1;
    int i = 0;
    char* arr;
    if (num == 0){
        return '\0';
    }
    
    if  (num < 0){
        sign = -1;
        num = -num;
    }
    int n = num;
    while (n > 0) {
    n /= 10;
    count++;
}
    if (sign < 0){
        arr = (char*)malloc((count + 2)*sizeof(char));
    *(arr + 0) = '-';
    count++;
    }
    else{
        arr = (char*)malloc((count + 1)*sizeof(char));

    } 
    while (num > 0){
     int r = num % 10;
     num /= 10;
    *(arr + (count - i - 1)) = r + '0';
    i++;
 }
 *(arr + count) = '\0' ;
 return arr;
}


#endif